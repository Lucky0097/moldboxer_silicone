import bpy  # type: ignore
from bpy.props import FloatProperty, IntProperty, BoolProperty, StringProperty  # type: ignore

bpy.types.Scene.master_voxel_size = FloatProperty(
    name="Master Detail",
    description="Master voxel detail size. Lower values will make the master more detailed but it will take more time (0.05 to 1)",
    default=0.15,
    min=0.05,
    max=1,
)

bpy.types.Scene.master_quality = bpy.props.EnumProperty(
    name="Master",
    description="Master heal speed/quality. Only applies if the master mesh needs to be healed",
    items=[
        ("FAST", "Fast", "Low detail, fast processing"),
        ("MID", "Balanced", "Medium detail"),
        ("HIGH", "High Detail", "Slow but detailed"),
        ("ULTRA", "Ultra Detail", "Very detailed"),
    ],
    default="MID",
)

bpy.types.Scene.box_gap = FloatProperty(
    name="Silicone Thickness",
    description="Silicone Mold Thickness",
    default=4.5,
)


bpy.types.Scene.box_quality = bpy.props.EnumProperty(
    name="Box",
    description="Box generation speed and quality",
    items=[
        ("FAST", "Fast", "Low detail, fast processing"),
        ("MID", "Balanced", "Medium detail"),
        ("HIGH", "High Detail", "Slow but detailed"),
        ("ULTRA", "Ultra Detail", "Very detailed"),
    ],
    default="MID",
)


bpy.types.Scene.build_from_sphere = BoolProperty(
    name="Safe Mode Box",
    description="Remove any possible gaps from the box, but make it less adjusted to the contour",
    default=False,
)


bpy.types.Scene.channel_width = FloatProperty(
    name="Width",
    description="Width of the channel",
    default=6,
)

bpy.types.Scene.channel_depth = FloatProperty(
    name="Depth",
    description="Depth of the channel",
    default=6,
)


bpy.types.Scene.channel_adjust_to_contour = BoolProperty(
    name="Countour Adapted",
    description="Adjust the channel to the contour",
    default=False,
)
bpy.types.Scene.channel_back_larger = BoolProperty(
    name="Larger Back",
    description="Make the back channel larger",
    default=True,
)

bpy.types.Scene.wing_join_patron = BoolProperty(
    name="Fixed Master",
    description="Join the patron to the wing",
    default=True,
)


bpy.types.Scene.n_splits = IntProperty(
    name="Nº Splits",
    description="Number of splits of the box",
    default=2,
)


# Grip

bpy.types.Scene.grip_height = FloatProperty(
    name="H",
    description="Height of the grip",
    default=10,
)

# Clean
bpy.types.Scene.cut_clean_height = FloatProperty(
    name="Height",
    description="Height to clean or cut",
    default=1,
)

## Master Holes

bpy.types.Scene.master_holes_depth = FloatProperty(
    name="D",
    description="Depth of the master holes",
    default=3,
)


## Volume
bpy.types.Scene.volume = FloatProperty(
    name="Volume",
    description="Volume of the mold",
    default=0,
)

## Grid
bpy.types.Scene.grid_distance = FloatProperty(
    name="Distance",
    description="Distance between the grid",
    default=4,
)
bpy.types.Scene.grid_rows = IntProperty(
    name="Rows",
    description="Number of rows of the grid",
    default=3,
)
bpy.types.Scene.grid_columns = IntProperty(
    name="Columns",
    description="Number of columns of the grid",
    default=3,
)

## Import
bpy.types.Scene.import_model = StringProperty(
    name="Master",
    description="Import Master Model",
    default="//",
    subtype="FILE_PATH",
)

## EXPORT

bpy.types.Scene.export_stl_folder = StringProperty(
    name="Folder",
    description="Folder to export the mold system",
    default="//",
    subtype="DIR_PATH",
)

## Utils
bpy.types.Scene.decimate_factor = FloatProperty(
    name="Factor",
    description="Decimate factor",
    default=0.2,
)

bpy.types.Scene.clear_extraction = BoolProperty(
    name="Clear extraction",
    description="Clear extraction",
    default=True,
)

bpy.types.Scene.scale_height = FloatProperty(
    name="H (cm)",
    description="Height to scale the object to in centimeters",
    default=10,
)
