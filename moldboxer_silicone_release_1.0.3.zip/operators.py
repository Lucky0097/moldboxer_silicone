import mathutils  # type: ignore
import bpy  # type: ignore
import logging
from bpy.props import StringProperty  # type: ignore
from bpy_extras.io_utils import ImportHelper  # type: ignore

from .source.object import *
from .source.components.grip import *
from .source.components.deposit import *
from .source.components.wrapper import *
from .source.components.channels import *
from .source.components.silicone_mold import *
from .source.components.base import add_basing_to_system
from .source.components.splitter import split
from .source.constants import *
from .source.components.extraction import *
from .source.components.preprocess import *
from .source.devtools import reload_addon
from .source.bl_utils import import_model
from .source.components.confirm_mold import confirm_mold_req, space_mold_system
from .source.components.server import require_authentication

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SelectedObjectOperator(bpy.types.Operator):
    @classmethod
    def poll(cls, context):
        return context.object is not None


class SelectedFaceOperator(bpy.types.Operator):
    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == "MESH"


class HealPatron(SelectedObjectOperator):
    bl_idname = "silicone.heal_patron"
    bl_label = "Heal"
    bl_description = "Heal Patron"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        active_obj = Object(bpy.context.active_object)
        active_obj.apply_modifier(
            build_voxel_modifier(MASTER_QUALITY_MAP[context.scene.master_quality])
        )
        active_obj.apply_modifier(build_decimate_collapse(0.2))
        return {"FINISHED"}


class AutoBox(SelectedObjectOperator):
    bl_idname = "silicone.auto_box"
    bl_label = "Automatic Box"
    bl_description = "Auto Box"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.silicone.build_box()
        bpy.ops.silicone.build_channels()
        bpy.ops.silicone.confirm()
        return {"FINISHED"}


class CenterObj(SelectedObjectOperator):
    bl_idname = "silicone.center_obj"
    bl_label = "Center"
    bl_description = "Center the selected object to origin"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.origin_set(type="GEOMETRY_ORIGIN", center="BOUNDS")
        for obj_ in context.selected_objects:
            obj_.location = mathutils.Vector((0, 0, 0))
        show_popup("Centered")
        return {"FINISHED"}


class BuildBox(SelectedObjectOperator):
    bl_idname = "silicone.build_box"
    bl_label = "1. Build Wrapper"
    bl_description = "Build the raw mold box"
    bl_options = {"REGISTER", "UNDO"}

    @require_authentication
    def execute(self, context):
        preprocess_patron(MASTER_QUALITY_MAP[context.scene.master_quality])
        box = Wrapper(
            Object(bpy.data.objects.get("patron")),
            BOX_QUALITY_MAP[context.scene.box_quality],
            distance=context.scene.box_gap,
            n_wraps=2,
            decimate=False,
            build_from_sphere=context.scene.build_from_sphere,
        )
        if context.scene.clear_extraction:
            clear_horizontal_extraction_path(
                (context.scene.channel_width + 2) / 2,
                BOX_QUALITY_MAP[context.scene.box_quality],
            )
        box = Object(bpy.data.objects.get("box"))
        deposit_ = build_auto_deposit(box)
        deposit_.select()
        return {"FINISHED"}


class BuildChannels(bpy.types.Operator):
    bl_idname = "silicone.build_channels"
    bl_label = "2. Build Channels"
    bl_description = "Build Channels"
    bl_options = {"REGISTER", "UNDO"}

    @require_authentication
    def execute(self, context):

        add_deposit()
        build_channels(
            context.scene.channel_width,
            context.scene.channel_depth,
            adjust_to_contour=context.scene.channel_adjust_to_contour,
            larger_back=context.scene.channel_back_larger,
        )

        return {"FINISHED"}


class Confirm(bpy.types.Operator):
    bl_idname = "silicone.confirm"
    bl_label = "3. Confirm"
    bl_description = "Confirm"
    bl_options = {"REGISTER", "UNDO"}

    @require_authentication
    def execute(self, context):
        recut_channels()
        add_channels()
        volume = build_silicone_mold_preview(
            BOX_QUALITY_MAP[context.scene.box_quality],
        )
        context.scene.volume = volume
        ### Server
        logger.info(f"Executing confirm_mold_req")
        confirm_mold_req(
            BOX_QUALITY_MAP[context.scene.box_quality],
            context.scene.channel_width,
            context.scene.n_splits,
        )
        ### Server

        add_basing_to_system(
            context.scene.volume,
            context.scene.wing_join_patron,
        )
        split(context.scene.n_splits)
        space_mold_system()

        return {"FINISHED"}


class CleanAllTop(SelectedObjectOperator):
    bl_idname = "silicone.clean_all_top"
    bl_label = "Clean All Top"
    bl_description = "Clean All Top"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        selected_obj = Object(bpy.context.active_object)
        selected_obj.clean_top(selected_obj.height - 0.1)
        return {"FINISHED"}


class CleanTop(SelectedObjectOperator):
    bl_idname = "silicone.clean_top"
    bl_label = "Clean Top"
    bl_description = "Clean Top"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        Object(bpy.context.active_object).clean_top(context.scene.cut_clean_height)
        return {"FINISHED"}


class CleanBot(SelectedObjectOperator):
    bl_idname = "silicone.clean_bot"
    bl_label = "Clean Bot"
    bl_description = "Clean Bottom"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        Object(bpy.context.active_object).clean_bot(context.scene.cut_clean_height)
        return {"FINISHED"}


class CutBot(SelectedObjectOperator):
    bl_idname = "silicone.cut_bot"
    bl_label = "Cut Bot"
    bl_description = "Cut Bottom"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        selected_obj = Object(bpy.context.active_object)
        selected_obj.select()
        selected_obj.cut_plane(
            mathutils.Vector((0, 0, -1)),
            mathutils.Vector(
                (0, 0, selected_obj.min_z + context.scene.cut_clean_height)
            ),
        )
        return {"FINISHED"}


class BuildGrip(bpy.types.Operator):
    bl_idname = "silicone.build_grip"
    bl_label = "Build Grip"
    bl_description = "Build Grip"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        build_grip(context.scene.grip_height)
        return {"FINISHED"}


class AddGrip(bpy.types.Operator):
    bl_idname = "silicone.add_grip"
    bl_label = "Add Grip"
    bl_description = "Add Grip"
    bl_options = {"REGISTER", "UNDO"}

    @require_authentication
    def execute(self, context):
        add_grip()
        return {"FINISHED"}


class Grid(SelectedObjectOperator):
    bl_idname = "silicone.grid"
    bl_label = "Grid"
    bl_description = "Grid the object with arrays"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        """Grid the object with arrays"""
        active_obj = Object(bpy.context.active_object)
        active_obj.grid_obj(
            context.scene.grid_rows,
            context.scene.grid_columns,
            context.scene.grid_distance,
        )
        bpy.ops.silicone.center_obj()

        return {"FINISHED"}


class Decimate(SelectedObjectOperator):
    bl_idname = "silicone.decimate"
    bl_label = "Decimate"
    bl_description = "Decimate"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        selected_obj = Object(bpy.context.active_object)
        selected_obj.apply_modifier(
            build_decimate_collapse(context.scene.decimate_factor)
        )
        return {"FINISHED"}


class ImportModel(bpy.types.Operator, ImportHelper):
    bl_idname = "silicone.import_model"
    bl_label = "Import"
    bl_description = "Import models (OBJ, STL)"
    bl_options = {"REGISTER", "UNDO"}

    filter_glob: StringProperty(default="*.stl;*.obj", options={"HIDDEN"})  # type: ignore

    def execute(self, context):
        import_model(self.filepath)
        return {"FINISHED"}


class ExportSTL(bpy.types.Operator, ImportHelper):
    bl_idname = "silicone.export_stl"
    bl_label = "Export"
    bl_description = "Export STLs"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        export(self.filepath, context.scene.volume)
        return {"FINISHED"}


class ReloadAddon(bpy.types.Operator):
    bl_idname = "silicone.reload_self"
    bl_label = "Reload Moldboxer"
    bl_description = "Reload addon"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        return reload_addon(self)


class ScaleHeight(SelectedObjectOperator):
    bl_idname = "silicone.scale_height"
    bl_label = "Scale Z (cm)"
    bl_description = "Scale the object to given height in centimeters"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        selected_obj = Object(bpy.context.active_object)
        target_height = context.scene.scale_height * 10  # to mm
        scale = target_height / selected_obj.height
        for axis in range(3):
            selected_obj.scale(scale, axis=axis)
        return {"FINISHED"}
