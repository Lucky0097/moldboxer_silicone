import bpy  # type: ignore
from .source.constants import VERSION


class SiliconeMoldPanel(bpy.types.Panel):
    bl_category = "Moldboxer Silicone"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"


class MoldPanel(SiliconeMoldPanel):
    bl_label = "Mold"

    def draw(self, context):
        layout = self.layout

        # WRITE VERSION
        col = layout.column(align=True)
        col.label(text=f"Moldboxer Silicone {VERSION}")

        box = layout.box()
        col = box.column(align=True)
        row = col.row(align=True)
        row.operator("silicone.import_model", icon="IMPORT")
        row.operator("silicone.export_stl", icon="EXPORT")

        # -----------------
        # Automatic
        # -----------------
        box = layout.box()
        col = box.column(align=True)
        col.operator("silicone.auto_box", icon="LIGHT")

        # -----------------
        # Build
        # -----------------
        box = layout.box()
        box.label(text="Manual", icon="MODIFIER")
        col = box.column(align=True)

        col.operator("silicone.build_box", icon="MOD_SHRINKWRAP")
        col.operator("silicone.build_channels", icon="SNAP_EDGE")
        col.operator("silicone.confirm", icon="CHECKMARK")


class SettingsPanel(SiliconeMoldPanel):
    bl_label = "Settings"

    def draw(self, context):
        layout = self.layout

        # -----------------
        # Box / Geometry
        # -----------------
        box = layout.box()
        col = box.column(align=True)

        col.prop(context.scene, "box_gap", icon="OUTLINER_DATA_CURVES")
        col.prop(context.scene, "wing_join_patron", icon="DECORATE_LOCKED")
        col.prop(context.scene, "box_quality", expand=False)
        col.prop(context.scene, "master_quality", expand=False)
        col.prop(context.scene, "build_from_sphere", icon="FAKE_USER_ON")
        col.prop(context.scene, "clear_extraction", icon="MOD_BOOLEAN")

        # -----------------
        # Channels
        # -----------------
        box = layout.box()
        box.label(text="Channels", icon="CURVE_PATH")
        col = box.column(align=True)
        row = col.row(align=True)
        row.prop(context.scene, "channel_width", icon="FIXED_SIZE")
        row.prop(context.scene, "channel_depth", icon="FACE_CORNER")
        col.prop(
            context.scene, "channel_adjust_to_contour", icon="OUTLINER_OB_FORCE_FIELD"
        )
        col.prop(context.scene, "channel_back_larger", icon="OUTLINER_OB_CURVE")


class UtilsPanel(SiliconeMoldPanel):
    bl_label = "Utils"

    def draw(self, context):
        layout = self.layout

        # -----------------
        # General
        # -----------------
        box = layout.box()
        col = box.column(align=True)
        row = col.row(align=True)
        row.operator("silicone.scale_height", icon="CON_SIZELIMIT")
        row.prop(context.scene, "scale_height")
        row = col.row(align=True)
        row.operator("silicone.center_obj", icon="EMPTY_AXIS")
        row.operator("silicone.heal_patron", icon="FUND")
        row = col.row(align=True)
        row.operator("silicone.decimate", icon="MOD_DECIM")
        row.prop(context.scene, "decimate_factor", icon="FILE_REFRESH")

        # -----------------
        # Clean Cut
        # -----------------
        box = layout.box()
        box.label(text="Clean / Cut", icon="MOD_BOOLEAN")
        col = box.column(align=True)

        col.prop(context.scene, "cut_clean_height", icon="FIXED_SIZE")

        row = col.row(align=True)
        row.operator("silicone.clean_all_top", icon="FUND")
        row.operator("silicone.cut_bot", icon="INTERNET_OFFLINE")
        row = col.row(align=True)
        row.operator("silicone.clean_top", icon="ORPHAN_DATA")
        row.operator("silicone.clean_bot", icon="ORPHAN_DATA")

        # -----------------
        # Grid
        # -----------------
        box = layout.box()
        box.label(text="Grid", icon="MESH_GRID")
        col = box.column(align=True)

        row = col.row(align=True)
        row.operator("silicone.grid", icon="MESH_GRID")
        row.prop(context.scene, "grid_distance", icon="ARROW_LEFTRIGHT")

        row = col.row(align=True)
        row.prop(context.scene, "grid_rows", icon="AREA_SWAP")
        row.prop(context.scene, "grid_columns", icon="AREA_JOIN_UP")

        # -----------------
        # Grip
        # -----------------
        box = layout.box()
        box.label(text="Grip", icon="MOD_SOLIDIFY")
        col = box.column(align=True)

        row = col.row(align=True)
        row.operator("silicone.build_grip", icon="MESH_CUBE")
        row.prop(context.scene, "grip_height")

        col.operator("silicone.add_grip", icon="ADD")

        ## Dev reload TODO: remove for release
        box = layout.box()
        col = box.column(align=True)
        col.operator("silicone.reload_self", icon="FILE")
