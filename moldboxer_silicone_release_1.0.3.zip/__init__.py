bl_info = {
    "name": "Moldboxer Silicone",
    "author": "DRP",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > N-panel",
    "category": "Object",
}

import bpy  # type: ignore
import importlib

from .properties import *
from .operators import *
from .panels import *
from .source.bl_utils import force_update_check, add_extension_repo


CLASSES = (
    AutoBox,
    CenterObj,
    BuildBox,
    BuildChannels,
    Confirm,
    CleanAllTop,
    CleanTop,
    CleanBot,
    CutBot,
    BuildGrip,
    AddGrip,
    Grid,
    ExportSTL,
    MoldPanel,
    SettingsPanel,
    UtilsPanel,
    ReloadAddon,
    ImportModel,
    Decimate,
    HealPatron,
    ScaleHeight,
)

addon_keymaps = []


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    # force_update_check()
    add_extension_repo("https://github.com/DRP-Lab/moldboxer_silicone")


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name="Window", space_type="EMPTY")
    kmi = km.keymap_items.new(
        ReloadAddon.bl_idname,
        type="R",
        value="PRESS",
        ctrl=True,
        alt=True,
    )
    addon_keymaps.append((km, kmi))


# if "bpy" in locals():
#     for km, kmi in addon_keymaps:
#         km.keymap_items.remove(kmi)
#     addon_keymaps.clear()
#     for m in (operators, panels, properties):
#         importlib.reload(m)
